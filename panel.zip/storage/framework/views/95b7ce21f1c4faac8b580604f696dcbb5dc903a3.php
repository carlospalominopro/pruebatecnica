<div class="table-responsive" style="text-align: center;">
    <table class="table" id="products-table">
        <thead>
            <tr>
                <th>ID Producto</th>
                <th>Nombre</th>
                <th>Subcategoría</th>
                <th>Estado</th>
                <th colspan="3">Acción</th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="<?php echo e($product->status == 0 ? 'disabled' : ''); ?>">
                <td><?php echo $product->id; ?></td>
                <td><?php echo $product->name; ?></td>
            <td><?php echo $subcategory[$product->subcategory_id]; ?></td>
            <td><?php echo __('selects.status')[$product->status]; ?></td>
                <td>
                    <?php echo Form::open(['route' => ['admin.products.destroy', $product->id], 'method' => 'delete']); ?>

                    <div class='btn-group'>
                        <a href="<?php echo route('admin.products.show', [$product->id]); ?>" class='btn btn-default btn-xs bord'><i class="fa fa-eye"></i></a>
                        <a href="<?php echo route('admin.products.edit', [$product->id]); ?>" class='btn btn-default btn-xs bord'><i class="fa fa-edit"></i></a>
                        <?php echo Form::button('<i class="fa fa-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs bord', 'onclick' => "return confirm('Are you sure?')"]); ?>

                    </div>
                    <?php echo Form::close(); ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH C:\xampp\htdocs\panel\resources\views/products/table.blade.php ENDPATH**/ ?>