<div class="table-responsive" style="text-align: center;">
    <table class="table" id="subcategories-table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
                <th>Categoría</th>
                <th colspan="3">Acción</th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="<?php echo e($subcategory->status == 0 ? 'disabled' : ''); ?>">
            <td><?php echo $subcategory->category_id; ?></td>
                <td><?php echo $subcategory->name; ?></td>
            <td><?php echo __('selects.status')[$subcategory->status]; ?></td>
                <td>
                    <?php echo Form::open(['route' => ['admin.subcategories.destroy', $subcategory->id], 'method' => 'delete']); ?>

                    <div class='btn-group'>
                        <a href="<?php echo route('admin.subcategories.show', [$subcategory->id]); ?>" class='btn btn-default btn-xs bord'><i class="fa fa-eye"></i></a>
                        <a href="<?php echo route('admin.subcategories.edit', [$subcategory->id]); ?>" class='btn btn-default btn-xs bord'><i class="fa fa-edit"></i></a>
                        <?php echo Form::button('<i class="fa fa-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs bord', 'onclick' => "return confirm('Are you sure?')"]); ?>

                    </div>
                    <?php echo Form::close(); ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH C:\xampp\htdocs\panel\resources\views/subcategories/table.blade.php ENDPATH**/ ?>