<div class="fields">

	<!-- Name Field -->
	<div class="form-group col-sm-4">
	    <?php echo Form::label('name', 'Nombre:'); ?>

	    <?php echo Form::text('name', null, ['class' => 'form-control', 'required']); ?>

	</div>

	<!-- Status Field -->
	<div class="form-group col-sm-4">
	    <?php echo Form::label('status', 'Estado:'); ?>

	    <?php echo Form::select('status', __('selects.status') , null, ['class' => 'form-control', 'required']); ?>

	</div>
</div>

<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Enviar', ['class' => 'btn btn-success']); ?>

    <a href="<?php echo route('admin.categories.index'); ?>" class="btn btn-light">Cancelar</a>
</div>
<?php /**PATH C:\xampp\htdocs\panel\resources\views/categories/fields.blade.php ENDPATH**/ ?>