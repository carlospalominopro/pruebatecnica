<div class="fields">

	<!-- Name Field -->
	<div class="form-group col-sm-4">
	    <?php echo Form::label('name', 'Nombre:'); ?>

	    <?php echo Form::text('name', null, ['class' => 'form-control', 'required']); ?>

	</div>

	<!-- Status Id Field -->
	<div class="form-group col-sm-4">
	    <?php echo Form::label('status', 'Estado:'); ?>

	    <?php echo Form::select('status',  __('selects.status'), null, ['class' => 'form-control', 'required']); ?>

	</div>

	<!-- Category Id Field -->
	<div class="form-group col-sm-4">
	    <?php echo Form::label('category_id', 'Categoría:'); ?>

	    <?php echo Form::select('category_id', $categories ?? [], $subcategory->category_id ?? null, ['class' => 'form-control', 'required']); ?>

	</div>
	
<div>


<!-- Submit Field -->
<div class="form-group col-sm-12">
    <?php echo Form::submit('Enviar', ['class' => 'btn btn-success']); ?>

    <a href="<?php echo route('admin.subcategories.index'); ?>" class="btn btn-light">Cancelar</a>
</div>
<?php /**PATH C:\xampp\htdocs\panel\resources\views/subcategories/fields.blade.php ENDPATH**/ ?>