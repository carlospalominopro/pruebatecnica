<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <h1>
            <b>Editar Producto #<?php echo e($category->id); ?></b>
        </h1>
   </section>
   <div class="content">
        <?php echo $__env->make('adminlte-templates::common.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="center">
                <div class="box-body col-sm-12">
            
                    <?php echo Form::model($category, ['route' => ['admin.categories.update', $category->id], 'method' => 'patch']); ?>


                        <?php echo $__env->make('categories.fields', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                   <?php echo Form::close(); ?>

      
           </div>
       </div>
   </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\panel\resources\views/categories/edit.blade.php ENDPATH**/ ?>