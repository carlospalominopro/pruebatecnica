<?php $__env->startSection('content'); ?>
    <section class="content-header">
        <h1>
            <b>Crear Subcategoría</b>
        </h1>
    </section>
    <div class="content">
        <div class="box box-primary">

            <?php echo $__env->make('adminlte-templates::common.errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="center">
                <div class="box-body col-sm-12">
                    <?php echo Form::open(['route' => 'admin.subcategories.store']); ?>


                        <?php echo $__env->make('subcategories.fields', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\panel\resources\views/subcategories/create.blade.php ENDPATH**/ ?>