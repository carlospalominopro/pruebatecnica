<div class="table-responsive" style="text-align: center;">
    <table class="table" id="categories-table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre</th>
        <th>Estado</th>
                <th colspan="3">Acción</th>
            </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="<?php echo e($category->status == 0 ? 'disabled' : ''); ?>">
                <td><?php echo $category->id; ?></td>
                <td><?php echo $category->name; ?></td>
            <td><?php echo __('selects.status')[$category->status]; ?></td>
                <td>
                    <?php echo Form::open(['route' => ['admin.categories.destroy', $category->id], 'method' => 'delete']); ?>

                    <div class='btn-group'>
                        <a href="<?php echo route('admin.categories.show', [$category->id]); ?>" class='btn btn-default btn-xs bord'><i class="fa fa-eye"></i></a>
                        <a href="<?php echo route('admin.categories.edit', [$category->id]); ?>" class='btn btn-default btn-xs bord'><i class="fa fa-edit"></i></a>
                        <?php echo Form::button('<i class="fa fa-trash"></i>', ['type' => 'submit', 'class' => 'btn btn-danger btn-xs bord', 'onclick' => "return confirm('Are you sure?')"]); ?>

                    </div>
                    <?php echo Form::close(); ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php /**PATH C:\xampp\htdocs\panel\resources\views/categories/table.blade.php ENDPATH**/ ?>