<?php

return [


    'status' => [
            '1'=>'Activo',
            '0'=>'Inactivo',
    ],

];
