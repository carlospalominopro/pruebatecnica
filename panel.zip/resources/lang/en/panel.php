<?php

return [
    'site_title' => 'material dashboard',
];
